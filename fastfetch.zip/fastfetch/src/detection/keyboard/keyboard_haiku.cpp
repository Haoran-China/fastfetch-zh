extern "C" {
#include "keyboard.h"
#include "common/debug.h"
}

#include <interface/Input.h>
#include <support/List.h>

const char* ffDetectKeyboard(FFlist* devices /* List of FFKeyboardDevice */) {
    BList list;

    status_t status = get_input_devices(&list);
    if (status != B_OK) {
        FF_DEBUG("get_input_devices() failed: %d", (int) status);
        return "get_input_devices() failed";
    }

    for (int32 i = 0, n = list.CountItems(); i < n; i++) {
        BInputDevice* device = (BInputDevice*) list.ItemAt(i);
        if (device->Type() != B_KEYBOARD_DEVICE || !device->IsRunning()) {
            continue;
        }

        FFKeyboardDevice* item = FF_LIST_ADD(FFKeyboardDevice, *devices);
        ffStrbufInit(&item->serial);
        ffStrbufInitS(&item->name, device->Name());
    }

    return nullptr;
}
